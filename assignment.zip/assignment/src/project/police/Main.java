package project.police;

import java.util.Scanner;

public class Main {
    public static void getUser() {
        String id;
        String names;
        String plate;
        String violationType;
        String vehicleType;
        double Amount;
        String paymentStatus;
        Scanner sc = new Scanner(System.in);
        do {
            System.out.println("Enter driver ID (16 digits): ");
            id=sc.next();
        }  while (!id.matches("\\d{16}"));
        sc.nextLine();
        do {
            System.out.println("Enter driver names: ");
            names=sc.next();
        }  while (!names.matches("[a-zA-Z]+"));
        sc.nextLine();
        do {
            System.out.println("Enter vehicle plate number: ");
            plate=sc.next();
        }  while (!plate.matches("[A-Z]{3}\\d{3}[A-Z]"));
        sc.nextLine();
        do {
            System.out.println("Enter vehicle type: ");
            vehicleType=sc.next();
        }  while (!vehicleType.matches("[a-zA-Z]+"));
        sc.nextLine();
        do {
            System.out.println("Enter violation type: ");
            violationType=sc.next();
        }  while (!violationType.matches("[a-zA-Z]+"));
        sc.nextLine();
        Amount=0;
        paymentStatus="";

        System.out.println("Police");
        System.out.println("----------");
        System.out.println("1. violation entry");
        System.out.println("2. fine assessment");
        System.out.println("3. fine payment");
        System.out.println("0. exit");
        int choice=sc.nextInt();
        switch (choice){
            case 1:
                ViolationEntry violationEntry=new ViolationEntry(id,names,plate,vehicleType,violationType,Amount,paymentStatus);
                violationEntry.recordViolation();
                break;
            case 2:
                FineAssessment fineAssessment=new FineAssessment(id,names,plate,vehicleType,violationType,Amount,paymentStatus);
                fineAssessment.assessFine();
                break;
            case 3:
                FinePayment finePayment=new FinePayment(id,names,plate,vehicleType,violationType,Amount,paymentStatus);
                finePayment.processPayment();
                break;
            case 0:
                System.out.println("Thanks for using our system");
                break;
            default:
                System.out.println("invalid choice, do you want to retry?");
                String ch= sc.next();
                if (ch.equalsIgnoreCase("yes")){
                    getUser();
                }else {
                    System.out.println("thanks for using our system");
                }
        }
    }

    public static void main(String[] args) {
        getUser();
        Scanner sc=new Scanner(System.in);
        System.out.println("Do you want to go back?");
        String choice= sc.next();
        if (choice.equalsIgnoreCase("yes")){
            getUser();
        }else {
            System.out.println("Thanks for using our system");
        }
    }

}
