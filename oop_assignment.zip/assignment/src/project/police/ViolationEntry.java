package project.police;

public class ViolationEntry extends TrafficRecord{
    public ViolationEntry(String driverId, String driverName, String vehiclePlate, String vehicleType, String violationType, double fineAmount, String paymentStatus) {
        super(driverId, driverName, vehiclePlate, vehicleType, violationType, fineAmount, paymentStatus);
    }

    @Override
    public void recordViolation() {
        if (getViolationType().equalsIgnoreCase("speeding")|| getViolationType().equalsIgnoreCase("red_light")||getViolationType().equalsIgnoreCase("no_helmet")||getViolationType().equalsIgnoreCase("dui")){
            System.out.println("violation recorded successfully");
            setPaymentStatus("unpaid");
            System.out.println("Driver by the names of "+getDriverName()+" with ID "+getDriverId());
            System.out.println("have a violation of "+getViolationType()+" which is currently "+getPaymentStatus());
        }else{
            System.out.println("invalid violation type");
        }

    }

    @Override
    public void assessFine() {

    }

    @Override
    public void processPayment() {

    }
}
