package project.police;

import java.util.Scanner;

public class FinePayment extends TrafficRecord{
    public FinePayment(String driverId, String driverName, String vehiclePlate, String vehicleType, String violationType, double fineAmount, String paymentStatus) {
        super(driverId, driverName, vehiclePlate, vehicleType, violationType, fineAmount, paymentStatus);
    }

    @Override
    public void recordViolation() {

    }

    @Override
    public void assessFine() {

    }

    @Override
    public void processPayment() {
        if (getPaymentStatus().equalsIgnoreCase("unpaid")){
            System.out.println("you will pay "+getFineAmount());
            Scanner sc=new Scanner(System.in);
            System.out.println("do you wish to pay ?");
            String choice=sc.next();
            if (choice.equalsIgnoreCase("yes")){
                paymentStatus="paid";
                System.out.println("dear "+getDriverName()+" with id "+getDriverId());
                System.out.println("vehicle of "+getVehicleType()+" with plate number "+getVehiclePlate());
                System.out.println("you have paid "+getFineAmount()+" now your status changed to "+getPaymentStatus());
            } else if (choice.equalsIgnoreCase("no")) {
                System.out.println("your status hasn't changed");
            }else {
                System.out.println("invalid choice");
                System.out.println("do you wish to retry?");
                choice=sc.next();
                if (choice.equalsIgnoreCase("yes")){
                    processPayment();
                }else{
                    System.out.println("thanks for using our system");
                }
            }
        }else {
            System.out.println("you have no fine");
        }
    }
}
