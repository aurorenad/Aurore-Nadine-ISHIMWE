package project.police;

public class FineAssessment extends TrafficRecord{
    public FineAssessment(String driverId, String driverName, String vehiclePlate, String vehicleType, String violationType, double fineAmount, String paymentStatus) {
        super(driverId, driverName, vehiclePlate, vehicleType, violationType, fineAmount, paymentStatus);
    }

    @Override
    public void recordViolation() {

    }

    @Override
    public void assessFine() {
        if (getViolationType().equalsIgnoreCase("speeding")){
            setFineAmount(50000);
            System.out.println("fine is "+getFineAmount());
        } else if (getViolationType().equalsIgnoreCase("red_light")) {
            setFineAmount(80000);
            System.out.println("fine is "+getFineAmount());
        } else if (getViolationType().equalsIgnoreCase("no_helmet")) {
            setFineAmount(30000);
            System.out.println("fine is "+getFineAmount());
        } else if (getViolationType().equalsIgnoreCase("dui")) {
            setFineAmount(150000);
            System.out.println("fine is "+getFineAmount());
        }else{
            System.out.println("invalid violation type");
        }
    }

    @Override
    public void processPayment() {

    }
}
