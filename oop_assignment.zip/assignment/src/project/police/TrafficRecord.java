package project.police;

public abstract class TrafficRecord {
    private String driverId;
    private String driverName;
    private String vehiclePlate;
    private String vehicleType;
    private String violationType;

    public TrafficRecord(String driverId, String driverName, String vehiclePlate, String vehicleType, String violationType, double fineAmount, String paymentStatus) {
        this.driverId = driverId;
        this.driverName = driverName;
        this.vehiclePlate = vehiclePlate;
        this.vehicleType = vehicleType;
        this.violationType = violationType;
        this.fineAmount = fineAmount;
        this.paymentStatus = paymentStatus;
    }

    public String getDriverId() {
        return driverId;
    }

    public void setDriverId(String driverId) {
        this.driverId = driverId;
    }

    public String getDriverName() {
        return driverName;
    }

    public void setDriverName(String driverName) {
        this.driverName = driverName;
    }

    public String getVehiclePlate() {
        return vehiclePlate;
    }

    public void setVehiclePlate(String vehiclePlate) {
        this.vehiclePlate = vehiclePlate;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getViolationType() {
        return violationType;
    }

    public void setViolationType(String violationType) {
        this.violationType = violationType;
    }

    public double getFineAmount() {
        return fineAmount;
    }

    public void setFineAmount(double fineAmount) {
        this.fineAmount = fineAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    double fineAmount;
    String paymentStatus;
    public abstract void recordViolation();
    public abstract void assessFine();
    public abstract void processPayment();
}
