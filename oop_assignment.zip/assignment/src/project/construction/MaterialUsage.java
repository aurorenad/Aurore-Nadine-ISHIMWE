package project.construction;

import java.util.Scanner;

public class MaterialUsage extends ConstructionMaterial{
    public MaterialUsage(int contractorId, String contractorName, double materialQuantity, double materialBalance) {
        super(contractorId, contractorName, materialQuantity, materialBalance);
    }

    @Override
    public void receiveMaterial() {

    }

    @Override
    public void usedMaterial() {
        System.out.println("how many material do you need? ");
        Scanner sc=new Scanner(System.in);
        materialQuantity=sc.nextDouble();
        if (materialBalance-materialQuantity>=2){
            materialBalance-=materialQuantity;
            System.out.println(getContractorId());
            System.out.println(getContractorName());
            System.out.println("you can use the material");
            System.out.println("you are left with "+materialBalance);
        }else {
            System.out.println("insufficient material");
            System.out.println("do you want to retry?");
            String choice=sc.next();
            if (choice.equalsIgnoreCase("yes")){
                usedMaterial();
            }else {
                System.out.println("thank you for using our system");
            }
        }

    }

    @Override
    public void estimatedCost() {

    }
}
