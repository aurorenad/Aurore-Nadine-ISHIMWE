package project.construction;

import java.util.Scanner;

public class MaterialDelivery extends ConstructionMaterial{
    public MaterialDelivery(int contractorId, String contractorName, double materialQuantity, double materialBalance) {
        super(contractorId, contractorName, materialQuantity, materialBalance);
    }

    @Override
    public void receiveMaterial() {
        System.out.println("Enter number of material you want to receive in tons: ");
        Scanner sc=new Scanner(System.in);
        materialQuantity=sc.nextDouble();
        if (materialQuantity>=1 && materialQuantity<=10){
            materialBalance+=materialQuantity;
            System.out.println(getContractorId());
            System.out.println(getContractorName());
            System.out.println("material balance is "+materialBalance);
        }else {
            System.out.println("Invalid ton ");
            System.out.println("do you want to retry?");
            String choice=sc.next();
            if (choice.equalsIgnoreCase("yes")){
                receiveMaterial();
            }else {
                System.out.println("thank you for using our system");
            }
        }

    }

    @Override
    public void usedMaterial() {

    }

    @Override
    public void estimatedCost() {

    }
}
