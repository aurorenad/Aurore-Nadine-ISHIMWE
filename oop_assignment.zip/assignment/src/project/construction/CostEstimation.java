package project.construction;

import java.util.Scanner;

public class CostEstimation extends ConstructionMaterial{
    public CostEstimation(int contractorId, String contractorName, double materialQuantity, double materialBalance) {
        super(contractorId, contractorName, materialQuantity, materialBalance);
    }

    @Override
    public void receiveMaterial() {

    }

    @Override
    public void usedMaterial() {

    }

    @Override
    public void estimatedCost() {
        System.out.println("how many material you need?");
        Scanner sc=new Scanner(System.in);
        materialQuantity=sc.nextDouble();
        double amount;
        if (materialQuantity>=5 && materialQuantity<=15){
            amount=materialQuantity*200000;
            System.out.println(contractorId);
            System.out.println(contractorName);
            System.out.println("you will pay "+amount);
        } else if (materialQuantity>15) {
            amount=materialQuantity*180000;
            System.out.println(contractorId);
            System.out.println(contractorName);
            System.out.println("you will pay "+amount);
        }else {
            System.out.println("try again inputting a material");
            System.out.println("do you want to retry?");
            String choice=sc.next();
            if (choice.equalsIgnoreCase("yes")){
                usedMaterial();
            }else {
                System.out.println("thank you for using our system");
            }
        }
    }
}
