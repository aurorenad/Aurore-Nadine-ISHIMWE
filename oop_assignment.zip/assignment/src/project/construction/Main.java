package project.construction;

import java.util.Scanner;

public class Main {
    public static void getInfo(){
        Scanner sc=new Scanner(System.in);
        int id;
        String names;
        double quantity;
        while (true) {
            System.out.println("Enter contractor id: ");
            if (sc.hasNextInt()) {
                id = sc.nextInt();
                break;
            } else {
                System.out.println("Invalid input! Please enter a valid id number.");
                sc.next();
            }
        }
        sc.nextLine();
        do {
            System.out.println("Enter contractor's name: ");
            names = sc.next();
        } while (!names.matches("[a-zA-Z]+"));
        sc.nextLine();
        while (true) {
            System.out.println("Enter material quantity");
            if (sc.hasNextDouble()) {
                quantity=sc.nextDouble();
                break;
            } else {
                System.out.println("Invalid input! Please enter a valid quantity.");
                sc.next();
            }
        }
        sc.nextLine();
        double balance=quantity;
        MaterialDelivery materialDelivery=new MaterialDelivery(id,names,quantity,balance);
        MaterialUsage materialUsage=new MaterialUsage(id,names,quantity,balance);
        CostEstimation costEstimation=new CostEstimation(id,names,quantity,balance);
        System.out.println("OUR SERVICES");
        System.out.println("1. deliver material");
        System.out.println("2. use a material");
        System.out.println("3. cost");
        System.out.println("0. exit");
        int choice = sc.nextInt();
        switch (choice){
            case 1:
                materialDelivery.receiveMaterial();
                break;
            case 2:
                materialUsage.usedMaterial();
                break;
            case 3:
                costEstimation.estimatedCost();
                break;
            case 0:
                System.out.println("thanks for coming");
                break;
            default:
                System.out.println("invalid choice");
        }
    }
    public static void main(String[] args) {
        getInfo();
        Scanner sc=new Scanner(System.in);
        System.out.println("Do you want to go back?");
        String choice= sc.next();
        if (choice.equalsIgnoreCase("yes")){
            getInfo();
        }else {
            System.out.println("Thanks for using our system");
        }
    }

}
