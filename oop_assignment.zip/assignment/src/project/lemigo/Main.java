package project.lemigo;

import java.util.Scanner;

public class Main {
    public static void getInfo() {
        int id;
        String names;
        String roomtype;
        String roomStatus="";
        int days;
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Enter guest id: ");
            if (sc.hasNextInt()) {
                id = sc.nextInt();
                break;
            } else {
                System.out.println("Invalid input! Please enter a valid id number.");
                sc.next();
            }
        }
        sc.nextLine();
        do {
            System.out.println("Enter guest names: ");
            names = sc.next();
        } while (!names.matches("[a-zA-Z]+"));
        sc.nextLine();
        do {
            System.out.println("Enter room type: ");
            roomtype = sc.next();
        } while (!(roomtype.equalsIgnoreCase("standard")|| roomtype.equalsIgnoreCase("deluxe")|| roomtype.equalsIgnoreCase("suite")));
        sc.nextLine();
        while (true) {
            System.out.println("Enter stay days: ");
            if (sc.hasNextInt()) {
                days = sc.nextInt();
                break;
            } else {
                System.out.println("Invalid input! Please enter a valid days.");
                sc.next();
            }
        }
        do {
            System.out.println("Enter room status: ");
            roomStatus = sc.next();
        } while (!(roomStatus.equalsIgnoreCase("available")|| roomStatus.equalsIgnoreCase("occupied")) );


        sc.nextLine();
        System.out.println("WELCOME TO OUR SITES");
        System.out.println("1. ROOM BOOKING");
        System.out.println("2. GUEST CHECKOUT");
        System.out.println("3. BILLING");
        System.out.println("0. exit");
        int choice = sc.nextInt();
        switch (choice) {
            case 1:
                RoomBooking roomBooking = new RoomBooking(id, names, roomtype, days, roomStatus);
                roomBooking.bookRoom();
                break;
            case 2:
                GuestCheckout guestCheckout = new GuestCheckout(id, names, roomtype, days, roomStatus);
                guestCheckout.checkoutGuest();
                break;
            case 3:
                Billing billing = new Billing(id, names, roomtype, days, roomStatus);
                billing.generateBill();
                break;
            case 0:
                System.out.println("thanks for using our system");
                break;
            default:
                System.out.println("invalid choice");
                System.out.println("do you want to retry?");
                String ch = sc.next();
                if (ch.equalsIgnoreCase("yes")) {
                    getInfo();
                } else {
                    System.out.println("thanks for using our system");
                }
        }
    }

    public static void main(String[] args) {
        getInfo();
        Scanner sc=new Scanner(System.in);
        System.out.println("Do you want to go back?");
        String choice= sc.next();
        if (choice.equalsIgnoreCase("yes")){
            getInfo();
        }else {
            System.out.println("Thanks for using our system");
        }
    }
}
