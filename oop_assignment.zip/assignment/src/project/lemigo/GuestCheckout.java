package project.lemigo;

public class GuestCheckout extends HotelService{
    public GuestCheckout(int guestId, String guestName, String roomType, int stayDays, String roomStatus) {
        super(guestId, guestName, roomType, stayDays, roomStatus);
    }

    @Override
    public void bookRoom() {

    }

    @Override
    public void checkoutGuest() {
        if (getRoomStatus().equalsIgnoreCase("occupied")){
            setRoomStatus("Available");
            System.out.println("the room is now "+getRoomStatus());
        }else {
            System.out.println("the room is already available");
        }
    }

    @Override
    public void generateBill() {

    }
}
