package project.lemigo;

import java.util.Scanner;

public class RoomBooking extends HotelService{
    public RoomBooking(int guestId, String guestName, String roomType, int stayDays, String roomStatus) {
        super(guestId, guestName, roomType, stayDays, roomStatus);
    }

    @Override
    public void bookRoom() {
        if (getRoomStatus().equalsIgnoreCase("available")){
            if (getStayDays()>=1 && getStayDays()<=30){
                setRoomStatus("occupied");
                System.out.println("booking successful! The room is now  "+getRoomStatus());
            }else {
                System.out.println("you can't book with us, retry by changing the days");
                System.out.println("do you want to retry?");
                Scanner sc = new Scanner(System.in);
                String choice = sc.next();
                if (choice.equalsIgnoreCase("yes")) {
                    bookRoom();
                } else {
                    System.out.println("Thanks for using our system");
                }
            }
        }else {
            System.out.println("room occupied");
        }
    }

    @Override
    public void checkoutGuest() {

    }

    @Override
    public void generateBill() {

    }

}
