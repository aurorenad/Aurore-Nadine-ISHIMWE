package project.lemigo;

public class Billing extends HotelService {
    public Billing(int guestId, String guestName, String roomType, int stayDays, String roomStatus) {
        super(guestId, guestName, roomType, stayDays, roomStatus);
    }

    @Override
    public void bookRoom() {


    }

    @Override
    public void checkoutGuest() {

    }

    @Override
    public void generateBill() {
        double amount, bill;
        System.out.println("Billing");
        System.out.println("__________");
        if (getRoomType().equalsIgnoreCase("Standard")) {
            amount = 50000;
            bill = amount * getStayDays();
            System.out.println("Guest ID "+getGuestId()+" with a name "+getGuestName());
            System.out.println("choose a room "+getRoomType() +" . they will stay for "+ getStayDays());
            System.out.println("you will pay per night " + amount);
            System.out.println("you will pay " + bill);
        } else if (getRoomType().equalsIgnoreCase("Deluxe")) {
            amount = 80000;
            bill = amount * getStayDays();
            System.out.println("Guest ID "+getGuestId()+" with a name "+getGuestName());
            System.out.println("choose a room "+getRoomType() +" . they will stay for "+ getStayDays());
            System.out.println("you will pay per night " + amount);
            System.out.println("you will pay " + bill);
        } else if (getRoomType().equalsIgnoreCase("Suite")) {
            amount = 120000;
            bill = amount * getStayDays();
            System.out.println("Guest ID "+getGuestId()+" with a name "+getGuestName());
            System.out.println("choose a room "+getRoomType() +" . they will stay for "+ getStayDays());
            System.out.println("you will pay per night " + amount);
            System.out.println("you will pay " + bill);
        }else {
            System.out.println("the room type is invalid");
        }

    }
}
