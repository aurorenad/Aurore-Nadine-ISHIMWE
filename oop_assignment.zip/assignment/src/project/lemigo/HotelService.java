package project.lemigo;

public abstract class HotelService  {
    private int guestId;
    private String guestName;
    private String roomType;
    private int stayDays;
    private String roomStatus;

    public HotelService(int guestId, String guestName, String roomType, int stayDays, String roomStatus) {
        this.guestId = guestId;
        this.guestName = guestName;
        this.roomType = roomType;
        this.stayDays = stayDays;
        this.roomStatus = roomStatus;
    }

    public int getGuestId() {
        return guestId;
    }

    public void setGuestId(int guestId) {
        this.guestId = guestId;
    }

    public String getGuestName() {
        return guestName;
    }

    public void setGuestName(String guestName) {
        this.guestName = guestName;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public int getStayDays() {
        return stayDays;
    }

    public void setStayDays(int stayDays) {
        this.stayDays = stayDays;
    }

    public String getRoomStatus() {

        return roomStatus;
    }

    public void setRoomStatus(String roomStatus) {
            this.roomStatus = roomStatus;


    }

    public abstract void bookRoom();
    public abstract void checkoutGuest();
    public abstract void generateBill();



}
